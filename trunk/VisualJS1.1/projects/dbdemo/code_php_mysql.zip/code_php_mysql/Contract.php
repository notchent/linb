<?php
include_once("ConnectionManager.php");

class ContractData{
   var $id = null;
   var $name = null;
   var $company = null;
   var $title = null;
   var $phone = null;
   var $memo = null;
}
    
class SerializeHelper{
   function ObjectToXmlString($randKey,$edArray){
      
      $dom = '{randkey:"' . $randKey . '",';
      $dom .= 'res : "ok",';
      $dom .= 'count : ' . sizeof($edArray) . ',';
      $dom .= 'data : [';
      
      $flag = false;
      foreach($edArray as $ed){
         if(!$flag){
             $dom .= '{'; 
             $flag = true; 
         }else{
             $dom .= ',{';
         }
         $dom .= 'id:"' . $ed->id . '",';
         $dom .= 'name:"' . $ed->name . '",';
         $dom .= 'company:"' . $ed->company . '",';
         $dom .= 'title:"' . $ed->title . '",';
         $dom .= 'phone:"' . $ed->phone . '",';
         $dom .= 'memo:"' . $ed->memo . '"'; 
         $dom .= '}';
      }
      $dom .= "]}"; 
      return $dom;
   }
   function QueryToObject($req){
      $emp = new ContractData();
      $emp->id = $req['id'];
      $emp->name = $req['name'];
      $emp->company = $req['company'];
      $emp->title = $req['title'];
      $emp->phone = $req['phone'];
      $emp->memo = $req['memo'];
      return $emp;
   }
}
  
    
class ContractHelper{
	function ReadData(){
		$conManager = new ConManager();
		$conManager->getConnection();
		$sql = "select * from contract";
		$handle = mysql_query($sql);
		
      $retArray = array();
		while ($row = mysql_fetch_array($handle)) {
			$ed = new ContractData();
      $ed->id = $row['id'];
      $ed->name = $row['name'];
      $ed->company = $row['company'];
      $ed->title = $row['title'];
      $ed->phone = $row['phone'];
      $ed->memo = $row['memo'];
      $retArray[] = $ed;
		}
		return $retArray;
	}
	
	
	
	function DeleteData($randKey,$ed){
		$conManager = new ConManager();
		$conManager->getConnection();
		$sqlStr = "delete from contract where id=".$ed->id;
		mysql_query($sqlStr);
		$ret = '{"randkey" : "' . $randKey . '","res" : "ok", "count" : 1,"data" : [ {';
		$ret .= 'id:"' . $ed->id . '"} ]}';
		return $ret;
	}
	
   
	function UpdateData($randKey,$ed){
		$conManager = new ConManager();
		$conManager->getConnection();
		$sqlStr = "UPDATE contract SET ".
      "`name`='".$ed->name.
      "', `company`='".$ed->company.
      "', `title`='".$ed->title.
      "', `phone`='".$ed->phone.
      "', `memo`='".$ed->memo.
      "' where `id`=".$ed->id;
		  mysql_query($sqlStr);
		  
		  $ret = '{"randkey" : "' . $randKey . '","res" : "ok", "count" : 1,"data" : [ {';
		  $ret .= 'id:"' . $ed->id . '",';
      $ret .= 'name:"' . $ed->name . '",';
      $ret .= 'company:"' . $ed->company . '",';
      $ret .= 'title:"' . $ed->title . '",';
      $ret .= 'phone:"' . $ed->phone . '",';
      $ret .= 'memo:"' . $ed->memo . '"} ]}';
		  return $ret;
  	}
	
   
	function InsertData($randKey,$ed){
		$conManager = new ConManager();
		$conManager->getConnection();
		$sqlStr = "insert into contract (`name`, `company`, `title`, `phone`, `memo`) VALUES ('".
      $ed->name."', '".$ed->company."', '".$ed->title."', '".$ed->phone."', '".$ed->memo."')";
		mysql_query($sqlStr);
		$ed->id = mysql_insert_id();
		$ret = '{"randkey" : "' . $randKey . '","res" : "ok", "count" : 1,"data" : [ {';
		$ret .= 'id:"' . $ed->id . '"} ]}';
		return $ret;
	}
}

?>