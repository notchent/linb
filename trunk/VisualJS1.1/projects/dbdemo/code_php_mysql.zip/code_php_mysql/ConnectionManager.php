<?php
class ConManager{
	function getConnection(){
		mysql_connect("localhost","sigma8_linb","tao81270")or
         die("Could not connect: " . mysql_error());
		mysql_select_db("sigma8_linb");
	}
}
?>