-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 30, 2008 at 07:27 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `contract`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `contract`
-- 

CREATE TABLE `contract` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `company` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `memo` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- Dumping data for table `contract`
-- 

INSERT INTO `contract` (`id`, `name`, `company`, `title`, `phone`, `memo`) VALUES 
(2, 'Tom', 'Microsoft', 'SEO', '4567890qqq', 'FromMS'),
(3, 'Steven', 'Sigmasoft', 'Manager', '0987654321', 'Cheers'),
(13, 'Tom', 'Microsoft', 'SEO', '4567890qqq', 'FromMS'),
(14, 'Tom', 'Microsoft', 'SEO', '4567890qqq', 'FromMS');
