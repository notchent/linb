<?php
include_once("Contract.php");
header('Content-type:text/javascript;charset=UTF-8');
switch ($_REQUEST['api']) {
	case 'list':
		ListContract();
		break;
	case 'update':
		UpdateContract();
		break;
	case 'del':
		DeleteContract();
		break;
	case 'add':
		InsertContract();
		break;	
}

function ListContract(){
   $eh = new ContractHelper();
   $sh = new SerializeHelper();
   $ret = $sh->ObjectToXmlString($_REQUEST["randkey"],$eh->ReadData());
   echo $_REQUEST["callback"] . '(' . $ret . ')'; 
}

function InsertContract(){
   $eh = new ContractHelper();
   $sh = new SerializeHelper();
   $ret = $eh->InsertData($_REQUEST["randkey"],$sh->QueryToObject($_REQUEST));
   echo $_REQUEST["callback"] . '(' . $ret . ')';  
   
}
function UpdateContract(){
   $eh = new ContractHelper();
   $sh = new SerializeHelper();
   $ret = $eh->UpdateData($_REQUEST["randkey"],$sh->QueryToObject($_REQUEST));
   echo $_REQUEST["callback"] . '(' . $ret . ')';  
}
function DeleteContract(){
   $eh = new ContractHelper();
   $sh = new SerializeHelper();
   $ret = $eh->DeleteData($_REQUEST["randkey"],$sh->QueryToObject($_REQUEST));
   echo $_REQUEST["callback"] . '(' . $ret . ')';  
}

?>